#ifndef FRACTALFILEH
#define FRACTALFILEH

#include <stdio.h>

char* mountFractalStageFilePath (char* name, int stage);
char* mountFinalFractalFilePath (char* name);
char* mountFractalPicturePath (char* name);

#endif
